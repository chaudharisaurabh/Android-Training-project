package com.Deliciouspoint.Delicious.model

data class CartItems (
    var itemId:String,
    var itemName:String,
    var itemPrice:String,
    var restaurantId:String
)